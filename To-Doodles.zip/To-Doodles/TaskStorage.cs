﻿using System.Collections.Generic;

namespace To_Doodles;

public class TaskStorage
{
    public void StoreTasks(IEnumerable<Task> tasks)
    {
        // TODO: Hier kommt Code zum Speichern der Tasks in ein Text‑Dokument (z.B. JSON)
    }

    public List<Task> LoadTasks()
    {
        // TODO: Hier kommt Code zum Laden der Tasks aus einem Text‑Dokument
        return new List<Task>();
    }
}